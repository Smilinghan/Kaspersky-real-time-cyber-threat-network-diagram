# justthedate
widget for übersicht that displays just the date.

This widget will display just the date of today. You will need to adapt the way the date is displayed. The style matches the style of the fuzzy time widget for which this widget can serve as a companion.

Many thanks to https://github.com/plan8studios/fuzzytime for being an unsuspected donor

Edit index.coffee to customize
